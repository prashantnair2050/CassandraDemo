import com.datastax.oss.driver.api.core.CqlSession;
import com.datastax.oss.driver.api.core.cql.*;

import java.net.InetSocketAddress;

public class CassandraClientDemo {
    public static void main(String[] args) {
        try (CqlSession session = CqlSession.builder()
                .addContactPoint(new InetSocketAddress("192.168.199.130", 9042))
                .addContactPoint(new InetSocketAddress("192.168.199.132", 9042))
                .withLocalDatacenter("datacenter1")
                .build()) {

            SimpleStatement stmt = SimpleStatement.builder("SELECT * FROM hr.emp")
                    .setConsistencyLevel(com.datastax.oss.driver.api.core.ConsistencyLevel.QUORUM)
                    .build();

            ResultSet resultSet = session.execute(stmt);

            for (Row row : resultSet) {
                System.out.println("ID: " + row.getInt("eid") + ", Salary: " + row.getInt("esal"));
            }
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}

